《哥查德的大冒险》v3.2.0 电脑桌面原生版 (Windows x64)
1. 解压后请保持 GodchardAdventure.exe 与 GodchardAdventure.pck 在同一文件夹内，双击 GodchardAdventure.exe 即可运行（纯原生编译，非网页版、非安卓版）。
2. 电脑端操作：A/D 左右移动 · W/Space 跳跃 · J 射击 · U 魔剑斩击 · B 投掷炸弹 · E 切换双层空间 · G 开启不灭金身 · R 快速重开 · H 关卡提示 · Esc 系统设置与金币商城 · F11 全屏切换。
