哥查德的大冒险 v3.5.3 电脑桌面原生版 (Windows x64)：解压后保持 GodchardAdventure.exe 与 GodchardAdventure.pck 同级目录，双击运行（默认隐藏手机触控键，F11 切换全屏）。
